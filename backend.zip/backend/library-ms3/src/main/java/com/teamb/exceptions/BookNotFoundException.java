package com.teamb.exceptions;

@SuppressWarnings("serial")
public class BookNotFoundException extends RuntimeException {

}
