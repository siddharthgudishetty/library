insert into wallet values(100,100,'Hardik');
insert into wallet values(99,10,'sid');
