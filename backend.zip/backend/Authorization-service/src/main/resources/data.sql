insert into user
	(userid, city, dob,email,fname,gender,is_account_non_expired, is_account_non_locked, is_credentials_non_expired, is_enabled, lname, 
	 phone, pwd, roles, sq, sqa)
	values
	 (100,'hyd','1999-08-09','hardikhtalati@gmail.com','Hardik','male','true','true','true','true','Hardik Talati','9963918945',
	  '$2a$15$dqYcdZaMKSZPZhyF7ZJEW.B8d8lxxBzNH5fo2Rr.83tHhSrQ0sCTK','role_100',2, 'as');

	  
insert into user
	(userid, city, dob,email,fname,gender,is_account_non_expired, is_account_non_locked, is_credentials_non_expired, is_enabled, lname, 
	 phone, pwd, roles, sq, sqa)
	values
	 (99,'hyd','1999-08-09','sid@gmail.com','sid','male','true','true','true','true','g','9963918945',
	  '$2a$15$dqYcdZaMKSZPZhyF7ZJEW.B8d8lxxBzNH5fo2Rr.83tHhSrQ0sCTK','role_100',2,'as');