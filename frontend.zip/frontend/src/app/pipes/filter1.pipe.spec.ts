import { Filter1Pipe } from './filter1.pipe';

describe('Filter1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Filter1Pipe();
    expect(pipe).toBeTruthy();
  });
});
