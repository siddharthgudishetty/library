export class Order{
    fineId! : number;
    orderId! : number;
    walletId! : number;
    bookName!: string;
    amount! : number;
    transaction!: string;
    dateoftransaction!: Date;
    constructor(){}
    
}
