export class AuthenticationRequest{

    constructor(public userName:string,public password:string){
    }
  }