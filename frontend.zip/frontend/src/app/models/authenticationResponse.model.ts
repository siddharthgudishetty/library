export class AuthenticationResponse{

    constructor(public jwt:string){
        
    }
}