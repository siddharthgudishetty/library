export interface User {
    email: string;
    pwd: string;
    phone: string;
    fname: string;
    lname: string;
    city: string;
    sq: number;
    sqa: string;
    dob: Date;
    gender: string;
}